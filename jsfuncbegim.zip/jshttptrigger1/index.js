  
const appInsights = require("applicationinsights");
appInsights.setup("9cde3cbd-97fb-48f5-ab18-4379eacaab53")
.setAutoDependencyCorrelation(true)
.setDistributedTracingMode(appInsights.DistributedTracingModes.AI_AND_W3C)
.start();
const httpsRequest = require("https"); 

const demoHttpFunc = async function (context, req) {
    context.log.info('starting');
    var options = {
        host: 'httpfuncappbegim.azurewebsites.net',
        path: '/api/HttpTrigger1?code=a6hHoNqaG8pUDzq9C05eMkqEh0RaPTZiOv3N04wfdrSopT4M/cg6WA==&name=demo',
        method: 'POST',
        port: 443
    };
    callback = function(response) {
        var str = '';

        //another chunk of data has been received, so append it to `str`
        response.on('data', function (chunk) {
            str += chunk;
        });

        //the whole response has been received, so we just print it out here
        response.on('end', function () {
            context.log(str);
            context.done();
        });
    }
    httpsRequest.request(options, callback).end();

    context.res = {
        status: 200,
        body: "Wrapped function!!"
    };

    context.done();  
};

// Default export wrapped with Application Insights FaaS context propagation
export default async function contextPropagatingHttpTrigger(context, req) {
    // Start an AI Correlation Context using the provided Function context
    const correlationContext = appInsights.startOperation(context, req);

    // Wrap the Function runtime with correlationContext
    return appInsights.wrapWithCorrelationContext(async () => {
        const startTime = Date.now(); // Start trackRequest timer

        // Run the Function
        await demoHttpFunc(context, req);

        // Track Request on completion
        appInsights.defaultClient.trackRequest({
            name: context.req.method + " " + context.req.url,
            resultCode: context.res.status,
            success: true,
            url: req.url,
            duration: Date.now() - startTime,
            id: correlationContext.operation.parentId,
        });
        appInsights.defaultClient.flush();
    }, correlationContext)();
};
